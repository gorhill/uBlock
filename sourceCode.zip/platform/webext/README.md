The purpose of the `webext` target is to create a single package which
can be used for both Chromium and Firefox. Such package is a requirement
to have uBlock Origin shipped in Debian.
